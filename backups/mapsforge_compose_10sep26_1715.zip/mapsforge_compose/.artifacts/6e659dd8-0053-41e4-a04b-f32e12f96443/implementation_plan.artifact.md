# Improvement Plan for SettingsScreen Download Logic

The current implementation of `startGhzDownload`, `startMapDownload`, and `startHgtDownload` in `SettingsScreenContent` contains significant code duplication, manual state management, and performs I/O operations directly in the UI layer.

## Proposed Changes

### 1. Refactor to a Unified Download Helper
Introduce a private helper function `downloadAndProcess` to encapsulate the shared workflow:
- Setting loading states.
- Downloading to cache.
- Executing a custom processing block (extraction).
- Cleaning up the cache file.
- Error handling and logging.

### 2. Generalize Unzipping Logic
Move the manual zip extraction logic from `startMapDownload` and `startHgtDownload` into a reusable utility in `GhHelper` or a new `ZipUtils` object. This utility should support optional file extension filtering.

### 3. Move Logic to ViewModel (Architectural Recommendation)
The logic currently resides in the `SettingsScreenContent` Composable. It should ideally be moved to a `ViewModel` to survive configuration changes and better separate UI from business logic.

### 4. Improve Error Handling and State Management
- Use `try-finally` to ensure `isDownloading` is always reset.
- Replace hardcoded German strings with Android string resources for better localization support.

## Verification Plan

### Manual Verification
- Test downloading a GHZ file and verify extraction to the `gh/` folder.
- Test downloading a Map file and verify extraction to the `maps/` folder (filtering for `.map` files).
- Test downloading an HGT file and verify extraction to the `hgt/` folder.
- Verify that `isDownloading` and `downloadMessage` are updated correctly throughout the process.
- Verify that cache files are deleted after successful or failed processing.
