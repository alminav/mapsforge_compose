package com.almica.mapsforge_compose

import android.content.Context
import androidx.core.content.edit
import androidx.preference.PreferenceManager
import com.almica.mapsforge_compose.gh.Const
import timber.log.Timber

data class MapRegion(
    val id: String,
    val displayName: String,
    val downloadUrl: String,
    val fileName: String
)

object MapRegions {
    val AVAILABLE_REGIONS = listOf(
        MapRegion("world", "World", "", "world.map"),
        MapRegion("niedersachsen", "Niedersachsen", "https://download.mapsforge.org/maps/v5/europe/germany/niedersachsen.map", "niedersachsen.map"),
        MapRegion("sachsen-anhalt", "Sachsen-Anhalt", "https://download.mapsforge.org/maps/v5/europe/germany/sachsen-anhalt.map", "sachsen_anhalt.map"),
        MapRegion("balearen", "Balearen", "https://download.mapsforge.org/maps/v5/europe/spain/islas-baleares.map", "baleares.map"),
        MapRegion("kanaren", "Kanaren", "https://download.mapsforge.org/maps/v5/africa/canary-islands.map", "canary.map")
    )
}

data class RenderTheme(
    val id: String,
    val displayName: String,
    val relativePath: String
)

object RenderThemes {
    val AVAILABLE_THEMES = listOf(
        RenderTheme("cruiser", "Cruiser", "cruiser/default.xml"),
        RenderTheme("elevation", "Elevation", "elevate52/Elevate.xml"),
        RenderTheme("mapsforge", "Mapsforge", "mapsforge/osmarender.xml"),
        RenderTheme("outdooractive", "OutdoorActive", "outdooractive/outdooractive.xml"),
        RenderTheme("contrast", "Contrast", "render_contrast/render.xml"),
        RenderTheme("outdoor", "Outdoor", "render_outdoor/render.xml"),
        RenderTheme("simplyhike", "SimplyHike", "render_simplyhike/render.xml")
    )
}

data class RenderPreview(
    val id: String,
    val imageResId: Int
)
object RenderPreviews {
    val AVAILABLE_PREVIEWS = listOf(
        RenderPreview("cruiser", R.mipmap.screenshot_cruiser),
        RenderPreview("elevation", R.mipmap.screenshot_elevation),
        RenderPreview("mapsforge", R.mipmap.screenshot_mapsforge),
        RenderPreview("outdooractive", R.mipmap.screenshot_outdooractive),
        RenderPreview("contrast", R.mipmap.screenshot_contrast),
        RenderPreview("outdoor", R.mipmap.screenshot_outdoor),
        RenderPreview("simplyhike", R.mipmap.screenshot_simplyhike)
    )
}

class SettingsRepository(context: Context) {
    private val sharedPreferences = context.getSharedPreferences("app_settings", Context.MODE_PRIVATE)
    private val defaultPrefs = PreferenceManager.getDefaultSharedPreferences(context)
    private val locomotionKeyString = context.getString(R.string.setting_locomotion)

    fun getSelectedRegion(): MapRegion {
        val fileName = getSelectedMapFileName()
        return MapRegions.AVAILABLE_REGIONS.find { it.fileName == fileName } ?: MapRegions.AVAILABLE_REGIONS.first()
    }

    fun getSelectedMapFileName(): String? {
        return sharedPreferences.getString("selected_map_file_name", null)
    }

    fun setSelectedMapFileName(fileName: String?) {
        sharedPreferences.edit { putString("selected_map_file_name", fileName) }
    }

    fun getSelectedHgtFileName(): String? {
        return sharedPreferences.getString("selected_hgt_file_name", null)
    }

    fun setSelectedHgtFileName(fileName: String?) {
        Timber.i("Set HGT file name: $fileName")
        sharedPreferences.edit { putString("selected_hgt_file_name", fileName) }
    }

    fun getAltitudeCorrection(): Float {
        return sharedPreferences.getFloat("altitude_correction", 0.0f)
    }

    fun setAltitudeCorrection(correction: Float) {
        sharedPreferences.edit { putFloat("altitude_correction", correction) }
    }

    fun getFollowGps(): Boolean {
        return sharedPreferences.getBoolean("follow_gps", true)
    }

    fun setFollowGps(enabled: Boolean) {
        sharedPreferences.edit { putBoolean("follow_gps", enabled) }
    }

    fun getThemeFilePath(): String? {
        return sharedPreferences.getString("theme_file_path", null)
    }

    fun setThemeFilePath(path: String?) {
        sharedPreferences.edit { putString("theme_file_path", path) }
    }

    fun getSelectedThemeId(): String {
        return sharedPreferences.getString("selected_theme_id", "simplyhike") ?: "simplyhike"
    }

    fun setSelectedThemeId(id: String) {
        sharedPreferences.edit { putString("selected_theme_id", id) }
    }

    fun getSelectedTheme(): RenderTheme {
        val id = getSelectedThemeId()
        return RenderThemes.AVAILABLE_THEMES.find { it.id == id } ?: RenderThemes.AVAILABLE_THEMES.last() // simplyhike is last
    }

    fun getGraphHopperFolder(): String? {
        return sharedPreferences.getString("graphhopper_folder", null)
    }

    fun setGraphHopperFolder(folderName: String?) {
        sharedPreferences.edit { putString("graphhopper_folder", folderName) }
    }

    fun getLocomotionKey(): String {
        return defaultPrefs.getString(locomotionKeyString, Const.DEFAULT_LOCOMOTION) ?: Const.DEFAULT_LOCOMOTION
    }

    fun setLocomotionKey(key: String) {
        Timber.i("Set locomotion key: $key")
        defaultPrefs.edit { putString(locomotionKeyString, key) }
    }

    fun getRoundTripFactor(): Float {
        return sharedPreferences.getFloat("round_trip_factor", 0.5f)
    }

    fun setRoundTripFactor(factor: Float) {
        sharedPreferences.edit { putFloat("round_trip_factor", factor) }
    }

    fun getLastLatitude(): Double {
        return sharedPreferences.getFloat("last_latitude", 0.0f).toDouble()
    }

    fun setLastLatitude(lat: Double) {
        sharedPreferences.edit { putFloat("last_latitude", lat.toFloat()) }
    }

    fun getLastLongitude(): Double {
        return sharedPreferences.getFloat("last_longitude", 0.0f).toDouble()
    }

    fun setLastLongitude(lon: Double) {
        sharedPreferences.edit { putFloat("last_longitude", lon.toFloat()) }
    }

    fun getLastZoom(): Int {
        return sharedPreferences.getInt("last_zoom", 12)
    }

    fun setLastZoom(zoom: Int) {
        sharedPreferences.edit { putInt("last_zoom", zoom) }
    }

    fun getKeepScreenOn(): Boolean {
        return sharedPreferences.getBoolean("keep_screen_on", false)
    }

    fun setKeepScreenOn(enabled: Boolean) {
        sharedPreferences.edit { putBoolean("keep_screen_on", enabled) }
    }

    fun getLatLngGrid(): Boolean {
        return sharedPreferences.getBoolean("lat_lng_grid", false)
    }

    fun setLatLngGrid(enabled: Boolean) {
        sharedPreferences.edit { putBoolean("lat_lng_grid", enabled) }
    }
}
