# Refactor SettingsScreen for better performance and reusability

The goal is to improve the `SettingsScreen.kt` by refactoring the download list items to avoid I/O operations in the composition phase and to use a reusable component across all tabs.

## Proposed Changes

### [app]

#### [MODIFY] [SettingsScreen.kt](file:///C:/Users/altmi/AndroidStudioProjects/mapsforge_compose/app/src/main/java/com/almica/mapsforge_compose/SettingsScreen.kt)

- Rename `DownloadMapRow` to `DownloadItemRow` and ensure it is generic enough for Maps, HGT, and Routing items.
- Update `GeneralSettingsTab` to use `DownloadItemRow` for HGT downloads.
- Update `MapSettingsTab` to use `DownloadItemRow` (replaces `DownloadMapRow`).
- Update `RoutingSettingsTab`:
    - Refactor `ghItems` `derivedStateOf` to include `isDownloaded` status, comparing against `ghFolders`.
    - Replace the manual `Row` in the routing downloads list with `DownloadItemRow`.

## Verification Plan

### Automated Tests
- Build the project to ensure no compilation errors.
- `gradlew :app:assembleDebug`

### Manual Verification
- Open the Settings screen and verify that all three tabs (General, Maps, Routing) correctly show the download status of items.
- Verify that already downloaded items are greyed out and have a checkmark icon.
- Verify that clicking an item that is not yet downloaded triggers the download.
- Verify that the UI remains responsive when scrolling through long lists of download items.
