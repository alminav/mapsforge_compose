# Refactor MainStateHolder for Idiomatic Compose and Correct Initialization

This plan refactors `MainStateHolder` to use Compose property delegates (`by`) and ensures `mapFileExists` is correctly initialized by checking the file system on startup.

## Proposed Changes

### [Component: State Management]

#### [MODIFY] [MainState.kt](file:///C:/Users/altmi/AndroidStudioProjects/mapsforge_compose/app/src/main/java/com/almica/mapsforge_compose/MainState.kt)
- Refactor all `mutableStateOf` properties to use the `by` delegate.
- Remove the `State` suffix from property names for cleaner access.
- Correctly initialize `mapFileExists` by checking if the map file exists in `externalFilesDir`.
- Add necessary imports for `getValue` and `setValue`.

### [Component: UI]

#### [MODIFY] [MainUI.kt](file:///C:/Users/altmi/AndroidStudioProjects/mapsforge_compose/app/src/main/java/com/almica/mapsforge_compose/MainUI.kt)
- Update all references to `MainStateHolder` properties to remove `.value`.
- Update property names (removing the `State` suffix).

#### [MODIFY] [MainActivity.kt](file:///C:/Users/altmi/AndroidStudioProjects/mapsforge_compose/app/src/main/java/com/almica/mapsforge_compose/MainActivity.kt)
- No changes strictly required to the initialization itself, but verify if any other logic depends on the state object.

## Verification Plan

### Automated Tests
- Build the project to ensure no compile errors after refactoring.
- Run existing unit tests (if any).

### Manual Verification
- Deploy the app to a device.
- Verify that the map loads correctly if the file exists.
- Verify that the download progress and status update correctly.
- Verify that switching screens and regions still works as expected.
