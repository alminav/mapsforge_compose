# Fix Unresolved References and Compilation Errors

The project has several compilation errors following the addition of Gson. Most of these are due to outdated package names (`com.almica.ramani`) and missing utility classes/constants that were likely part of the original project from which these files were copied.

## Proposed Changes

### 1. Add Missing Utility Classes and Data Models
I will add `ManifestUtils`, `RoutesObject`, and related data models to `ChartUtils.kt` to satisfy the requirements of `MapUtils.kt`.

#### [MODIFY] [ChartUtils.kt](file:///C:/Users/altmi/AndroidStudioProjects/mapsforge_compose/app/src/main/java/com/almica/mapsforge_compose/charts/ChartUtils.kt)
- Add `RoutesObject`, `RouteObject`, and `PolylineObject` data classes.
- Add `ManifestUtils` object with `getApiKeyFromManifest` function.

### 2. Update Constants
I will add the missing constants `GMS_TAG` and `TXT_EXT` to the `charts/Const.kt` file.

#### [MODIFY] [Const.kt](file:///C:/Users/altmi/AndroidStudioProjects/mapsforge_compose/app/src/main/java/com/almica/mapsforge_compose/charts/Const.kt)
- Add `GMS_TAG` and `TXT_EXT`.

### 3. Fix Typography in Theme
I will create a default `Typography` definition to fix the error in `RamaniTheme.kt`.

#### [NEW] [Typography.kt](file:///C:/Users/altmi/AndroidStudioProjects/mapsforge_compose/app/src/main/java/com/almica/mapsforge_compose/charts/Typography.kt)
- Define the `Typography` object for Material3.

### 4. Update Imports and References
I will update `MapUtils.kt` and `RouteEntity.kt` to use the correct package names and resolve missing references.

#### [MODIFY] [MapUtils.kt](file:///C:/Users/altmi/AndroidStudioProjects/mapsforge_compose/app/src/main/java/com/almica/mapsforge_compose/charts/MapUtils.kt)
- Update imports from `com.almica.ramani.utils` to local package.
- Ensure `Const.TIME_PATTERN_LONG` is correctly referenced (imported from `gh.Const`).

#### [MODIFY] [RouteEntity.kt](file:///C:/Users/altmi/AndroidStudioProjects/mapsforge_compose/app/src/main/java/com/almica/mapsforge_compose/charts/RouteEntity.kt)
- Update imports from `com.almica.ramani` to local package.
- Use extensions from `GradientChart.kt` for formatting.

## Verification Plan

### Automated Tests
- Run `./gradlew :app:compileDebugKotlin` to ensure all compilation errors are resolved.

### Manual Verification
- None required for this phase as it's a compilation fix.
