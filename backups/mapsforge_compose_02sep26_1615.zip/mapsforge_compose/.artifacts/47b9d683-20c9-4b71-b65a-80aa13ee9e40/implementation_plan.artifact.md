# Refactor ghCalc to Suspend Function

Refactor the GraphHopper route calculation in `GhHelper` to use Kotlin Coroutines (`suspend` function) and structured concurrency, improving error handling and readability. Update `MainViewModel` to use this new API.

## Proposed Changes

### [gh](file:///C:/Users/altmi/AndroidStudioProjects/mapsforge_compose/app/src/main/java/com/almica/mapsforge_compose/gh/)

#### [MODIFY] [GhHelper.kt](file:///C:/Users/altmi/AndroidStudioProjects/mapsforge_compose/app/src/main/java/com/almica/mapsforge_compose/gh/GhHelper.kt)
- Add `GhRouteResult` data class to encapsulate route calculation results.
- Convert `ghCalc` from a callback-based function to a `suspend` function.
- Use `withContext(Dispatchers.IO)` for background operations.
- Improve error handling by checking `ghResponse.hasErrors()`.
- Use idiomatic Kotlin for list mapping and string formatting.

#### [MODIFY] [MainViewModel.kt](file:///C:/Users/altmi/AndroidStudioProjects/mapsforge_compose/app/src/main/java/com/almica/mapsforge_compose/MainViewModel.kt)
- Update `calculateRoute` to call the new `suspend ghCalc` within `viewModelScope`.
- Simplify point mapping as `ghCalc` now returns the correct `RoutePoint` type directly.

## Verification Plan

### Automated Tests
- Build the project to ensure no compilation errors after the API change.

### Manual Verification
- Deploy to device and trigger a route calculation.
- Verify that the route is correctly calculated and displayed on the map.
- Verify that errors (e.g., GH not initialized) are handled without crashing.
