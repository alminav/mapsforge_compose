package com.almica.mobiledatachecker

import android.content.Context
import android.content.SharedPreferences
import java.util.UUID

class PreferenceManager(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences(
        Constants.PREFS_NAME,
        Context.MODE_PRIVATE
    )

    fun getPhoneNumber(): String {
        return prefs.getString(Constants.KEY_PHONE_NUMBER, "+4915776049418") ?: "+4915776049418"
    }

    fun setPhoneNumber(number: String) {
        prefs.edit().putString(Constants.KEY_PHONE_NUMBER, number).apply()
    }

    fun getIntervalMinutes(): Long {
        return prefs.getLong(Constants.KEY_INTERVAL_MINS, 15L)
    }

    fun setIntervalMinutes(minutes: Long) {
        prefs.edit().putLong(Constants.KEY_INTERVAL_MINS, minutes).apply()
    }

    fun getOrCreateInstallationId(): String {
        var id = prefs.getString(Constants.KEY_INSTALLATION_ID, null)
        if (id.isNullOrEmpty()) {
            id = UUID.randomUUID().toString()
            prefs.edit().putString(Constants.KEY_INSTALLATION_ID, id).apply()
        }
        return id
    }
}
